First of all, THANK YOU for downloading the MARIA font.

MARIA font is a slab, sans-serif handwriting type that can be used to give you a pen like writing style for your designs.

Please let me know how can I help you, if you find bugs or need improvements for this font!

Kreativ Font 2013 - http://www.kreativfont.com - All rights reserved. 

FREE to use for PERSONAL use ONLY. For commercial use please contact me info@kreativfont.com

Changelog
------------------------------------
1.2  � added unknown character glyph. 
1.1  � a few font alignament fixes; naming and font properties properly edited.
1.0  � original release.

Support Contact Information
------------------------------------
Kreativ Font: http://www.kreativfont.com
Support email: info@kreativfont.com
Phone: +40-741-242-868